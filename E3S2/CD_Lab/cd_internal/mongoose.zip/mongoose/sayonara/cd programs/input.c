#include <stdio.h>
/*header file part*/
int main(int argc, char *argv[])
{
	//start
	printf("Hello, world\n");
	//end
}
